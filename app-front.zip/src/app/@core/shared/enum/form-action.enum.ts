export enum FormActionEnum {
  PAGE = 'page',
  MODAL = 'modal',
}
