export enum TaxTypeEnum {
  PERCENTAGE = 'PERCENTAGE',
  NUMERIC = 'NUMERIC',
}
