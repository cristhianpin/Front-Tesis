export interface IShareInfo {
  trnId?: string;
  trnType?: string;
  emails?: string[];
}
