import { Component } from '@angular/core';

@Component({
  selector: 'ngx-statement-account',
  template: `<router-outlet></router-outlet>`,
})
export class StatementAccountComponent {}
