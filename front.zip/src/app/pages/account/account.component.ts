import { Component } from '@angular/core';

@Component({
  selector: 'ngx-account',
  template: `<router-outlet></router-outlet>`,
})
export class AccountComponent {}
