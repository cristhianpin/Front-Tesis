import { Component } from '@angular/core';

@Component({
  selector: 'ngx-movement',
  template: `<router-outlet></router-outlet>`,
})
export class MovementComponent {}
