import { Component } from '@angular/core';

@Component({
  selector: 'ngx-user-detail',
  template: `<router-outlet></router-outlet>`,
})
export class UserDetailComponent {}
