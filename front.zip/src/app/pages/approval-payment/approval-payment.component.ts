import { Component } from '@angular/core';

@Component({
  selector: 'ngx-reject-payment',
  template: `<router-outlet></router-outlet>`,
})
export class ApprovalPaymentComponent {}
