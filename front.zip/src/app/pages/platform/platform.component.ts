import { Component } from '@angular/core';

@Component({
  selector: 'ngx-platform',
  template: `<router-outlet></router-outlet>`,
})
export class PlatformComponent {}
