export enum MovementReasonInEnum {
  DEPOSITO = 'IN - Depósito',
  DEVOLUCION = 'IN - Devolución',
  BONUS = 'IN - Bonus',
}
