export enum ParameterTypeEnum {
  character = 'character',
  numeric = 'numeric',
}
