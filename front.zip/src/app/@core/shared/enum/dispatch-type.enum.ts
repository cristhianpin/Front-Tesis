export enum DispatchTypeEnum {
  ELECTRONIC = 'ELECTRONIC',
  CHECK = 'CHECK',
}
