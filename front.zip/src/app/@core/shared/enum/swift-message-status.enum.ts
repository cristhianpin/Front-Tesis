export enum TrnStatusEnum {
  DRAFT = 'DRAFT',
  CREATED = 'CREATED',
  SENDING = 'SENDING',
  SENT = 'SENT',
  RECEIVED = 'RECEIVED',
}
