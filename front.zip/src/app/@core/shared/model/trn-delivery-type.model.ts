export interface ITrnDeliveryType {
  name: string;
  code: string;
  label: string;
}
