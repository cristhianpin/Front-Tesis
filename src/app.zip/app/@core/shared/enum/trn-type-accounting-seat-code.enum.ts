export enum TrnTypeAccountingSeatCodeEnum {
  XGIRO = 'XGIRO',
  XPOSICION = 'XPOSICION',
  XCOMISION = 'XCOMISION',
  XIMPUESTO = 'XIMPUESTO',
}
