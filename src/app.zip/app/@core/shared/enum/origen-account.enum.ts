export enum OrigenAccountEnum {
  BOOKING = 'Reserva',
  SALE = 'Directo',
}
