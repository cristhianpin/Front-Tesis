export enum BookingCountEnum {
  COUNT3 = '3',
  COUNT5 = '5',
  COUNT10 = '10',
  COUNT30 = '30',
  COUNT50 = '50',
}

export enum BookingCountAdminEnum {
  COUNT1 = '1',
  COUNT2 = '2',
  COUNT3 = '3',
  COUNT5 = '5',
  COUNT10 = '10',
  COUNT30 = '30',
  COUNT50 = '50',
}
