export enum PlataformDurationEnum {
  MES1 = '30',
  MES2 = '60',
  MES3 = '90',
  MES4 = '120',
  MES5 = '150',
  MES6 = '180',
  MES9 = '270',
  MES12 = '360',
}
