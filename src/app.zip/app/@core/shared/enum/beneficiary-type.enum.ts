export enum BeneficiaryTypeEnum {
  USER = 'NATURAL',
  LEGAL = 'LEGAL',
}
