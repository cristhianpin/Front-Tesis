export interface IUserRegister {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
}
