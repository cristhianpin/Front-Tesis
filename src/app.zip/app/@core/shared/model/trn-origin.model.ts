export interface ITrnOrigen {
  name: string;
  code: boolean;
  label: string;
}
