import { Component } from '@angular/core';

@Component({
  selector: 'ngx-sale',
  template: `<router-outlet></router-outlet>`,
})
export class SaleComponent {}
