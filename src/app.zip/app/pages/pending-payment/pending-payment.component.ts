import { Component } from '@angular/core';

@Component({
  selector: 'ngx-pending-payment',
  template: `<router-outlet></router-outlet>`,
})
export class PendingPaymentComponent {}
