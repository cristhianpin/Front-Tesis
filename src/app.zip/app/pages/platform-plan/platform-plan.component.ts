import { Component } from '@angular/core';

@Component({
  selector: 'ngx-platform-plan',
  template: `<router-outlet></router-outlet>`,
})
export class PlatformPlanComponent {}
