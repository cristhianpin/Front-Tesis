import { Component } from '@angular/core';

@Component({
  selector: 'ngx-course-detail',
  template: `<router-outlet></router-outlet>`,
})
export class CourseComponent {}
