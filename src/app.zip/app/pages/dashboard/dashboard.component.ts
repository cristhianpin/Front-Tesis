import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dashboard',
  template: `<router-outlet></router-outlet>`,
})
export class DashboardComponent {}
