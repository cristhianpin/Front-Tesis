import { Component } from '@angular/core';

@Component({
  selector: 'ngx-setting',
  template: `<router-outlet></router-outlet>`,
})
export class SettingComponent {}
