import { Component } from '@angular/core';

@Component({
  selector: 'ngx-company',
  template: `<router-outlet></router-outlet>`,
})
export class CompanyComponent {}
