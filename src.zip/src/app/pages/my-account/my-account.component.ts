import { Component } from '@angular/core';

@Component({
  selector: 'ngx-my-account',
  template: `<router-outlet></router-outlet>`,
})
export class MyAccountComponent {}
