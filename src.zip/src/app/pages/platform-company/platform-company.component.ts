import { Component } from '@angular/core';

@Component({
  selector: 'ngx-platform-company',
  template: `<router-outlet></router-outlet>`,
})
export class PlatformCompanyComponent {}
