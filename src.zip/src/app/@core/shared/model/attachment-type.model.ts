export interface IAttachmentType {
  id: string;
  code: string;
  name: string;
  enabled: boolean;
  trntype: string;
  mandatory: boolean;
}
