export interface ITrnStatus {
  name: string;
  code: string;
  label: string;
}
