export interface ITerms {
  id: string;
  terms: string;
  enabled: boolean;
}
