export enum TrnTypeEnum {
  FTI = 'FTI',
  FTO = 'FTO',
}
