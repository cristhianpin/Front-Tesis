export enum DeliveryTypeEnum {
  WEB = 'WEB',
  MAIL = 'MAIL',
  WHATSAPP = 'WHATSAPP',
  API = 'API',
}
