export enum PlanSlugEnum {
  P100 = 'p100',
  P300 = 'p300',
  P500 = 'p500',
}
