export enum TaxBeneficiaryTypeEnum {
  USER = 'USER',
  COMPANY = 'COMPANY',
  BOTH = 'BOTH',
}
