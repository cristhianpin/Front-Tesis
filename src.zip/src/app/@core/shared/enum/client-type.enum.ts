export enum ClientTypeEnum {
  USER = 'NATURAL',
  LEGAL = 'LEGAL',
}
