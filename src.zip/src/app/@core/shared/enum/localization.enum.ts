export enum LocalizationEnum {
  LOCAL = 'LOCAL',
  FOREIGN = 'FOREIGN',
}
