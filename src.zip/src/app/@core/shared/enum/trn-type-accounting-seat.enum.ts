export enum TrnTypeAccountingSeatEnum {
  DEBIT = 'DEBIT',
  CREDIT = 'CREDIT',
}
