export enum PayerTypeEnum {
  USER = 'NATURAL',
  LEGAL = 'LEGAL',
}
