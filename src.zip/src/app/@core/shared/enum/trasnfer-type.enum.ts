export enum TransferTypeEnum {
  FTI = 'FTI',
  FTO = 'FTO',
}
